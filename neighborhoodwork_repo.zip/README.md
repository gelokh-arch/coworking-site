# neighborhoodwork-site

This repo contains a simple static landing page and a Netlify Function to return live waitlist counts from Netlify Forms.

## Files
- `index.html` — landing page with Netlify form and live counter that calls `/.netlify/functions/count`
- `success.html` — thank you page
- `netlify/functions/count.js` — serverless function that queries Netlify Forms API and returns counts
- `netlify.toml` — Netlify config

## Deployment steps (summary)
1. Create a GitHub repo and upload these files (or push via Git).
2. In Netlify, connect the repo via **New site from Git**.
3. Add the following Environment variables in your Netlify site settings:
   - `NETLIFY_TOKEN` — a personal access token from your Netlify account
   - `NETLIFY_SITE_ID` — the Site ID shown in Netlify site settings
   - `TOTAL_FOUNDER_SLOTS` — integer, e.g. `300`
4. Deploy — Netlify will build and publish automatically.
5. Test the site and the function at `https://<your-site>/.netlify/functions/count`

If you want, I can walk you through connecting the repo to Netlify and setting env vars.
